﻿using AutoMapper;
using Bosch.eCommerce.Application.Dtos.ProductDtos;
using Bosch.eCommerce.Domain.Entities;

namespace Bosch.eCommerce.Application.Profiles
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles()
        {
            CreateMap<Product, ProductDto>();//FEtching All Products and Fetching Single product
            CreateMap<NewProductDto, Product>();//Insert
            CreateMap<EditProductDto, Product>();//Update
            CreateMap<DeleteProductDto, Product>();//Delete
        }
    }
}
