﻿using Bosch.eCommerce.Application.Dtos.CategoryDtos;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Categories.Queries.GetAllCategories
{
    public class GetAllCategoriesQuery:IRequest<List<CategoryDto>>
    {
    }
}
