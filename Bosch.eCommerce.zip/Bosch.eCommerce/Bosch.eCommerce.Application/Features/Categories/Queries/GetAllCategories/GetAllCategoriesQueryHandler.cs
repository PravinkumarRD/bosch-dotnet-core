﻿using AutoMapper;
using Bosch.eCommerce.Application.Contacts;
using Bosch.eCommerce.Application.Dtos.CategoryDtos;
using Bosch.eCommerce.Domain.Entities;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Categories.Queries.GetAllCategories
{
    public class GetAllCategoriesQueryHandler : IRequestHandler<GetAllCategoriesQuery, List<CategoryDto>>
    {
        private readonly ICommonRepository<Category> _repository;
        private readonly IMapper _mapper;
        public GetAllCategoriesQueryHandler(ICommonRepository<Category> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<List<CategoryDto>> Handle(GetAllCategoriesQuery request, CancellationToken cancellationToken)
        {
            var categories = await _repository.GetAllAsync();
            return _mapper.Map<List<CategoryDto>>(categories);    
        }
    }
}
