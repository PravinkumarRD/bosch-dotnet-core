﻿using Bosch.eCommerce.Application.Dtos.ProductDtos;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Products.Queries.GetAllProducts
{
    public class GetAllProductsQuery : IRequest<List<ProductDto>>
    {
    }
}
