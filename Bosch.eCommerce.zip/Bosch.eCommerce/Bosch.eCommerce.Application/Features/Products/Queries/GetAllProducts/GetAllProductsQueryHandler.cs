﻿using AutoMapper;
using Bosch.eCommerce.Application.Contacts;
using Bosch.eCommerce.Application.Dtos.ProductDtos;
using Bosch.eCommerce.Domain.Entities;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Products.Queries.GetAllProducts
{
    public class GetAllProductsQueryHandler:IRequestHandler<GetAllProductsQuery,List<ProductDto>>
    {
        private readonly ICommonRepository<Product> _repository;
        private readonly IMapper _mapper;
        public GetAllProductsQueryHandler(ICommonRepository<Product> repository,IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<List<ProductDto>> Handle(GetAllProductsQuery request, CancellationToken cancellationToken)
        {
            var products = await _repository.GetAllAsync();
            return _mapper.Map<List<ProductDto>>(products);
        }
    }
}
