﻿using Bosch.eCommerce.Application.Dtos.ProductDtos;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Products.Queries.GetProductDetails
{
    public class GetProductDetailsQuery : IRequest<ProductDto>
    {
        public int ProductId { get; set; }
    }
}
