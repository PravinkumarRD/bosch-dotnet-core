﻿using AutoMapper;
using Bosch.eCommerce.Application.Contacts;
using Bosch.eCommerce.Application.Dtos.ProductDtos;
using Bosch.eCommerce.Domain.Entities;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Products.Queries.GetProductDetails
{
    public class GetProductDetailsQueryHandler : IRequestHandler<GetProductDetailsQuery, ProductDto>
    {
        private readonly ICommonRepository<Product> _repository;
        private readonly IMapper _mapper;
        public GetProductDetailsQueryHandler(ICommonRepository<Product> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<ProductDto> Handle(GetProductDetailsQuery request, CancellationToken cancellationToken)
        {
            var product = await _repository.GetDetailsAsync(request.ProductId);
            return _mapper.Map<ProductDto>(product);
        }
    }
}
