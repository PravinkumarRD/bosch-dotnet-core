﻿using AutoMapper;
using Bosch.eCommerce.Application.Contacts;
using Bosch.eCommerce.Domain.Entities;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Products.Commands
{
    public class ProductInsertCommandHandler : IRequestHandler<ProductInsertCommand, int>
    {
        private readonly ICommonRepository<Product> _repository;
        private readonly IMapper _mapper;

        public ProductInsertCommandHandler(ICommonRepository<Product> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<int> Handle(ProductInsertCommand request, CancellationToken cancellationToken)
        {
            var product = _mapper.Map<Product>(request.Product);
            int result = await _repository.InsertAsync(product);
            return result;
        }
    }
}
