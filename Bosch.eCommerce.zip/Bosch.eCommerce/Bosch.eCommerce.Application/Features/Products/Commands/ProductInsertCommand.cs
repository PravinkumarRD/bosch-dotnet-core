﻿using Bosch.eCommerce.Application.Dtos.ProductDtos;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Products.Commands
{
    public class ProductInsertCommand : IRequest<int>
    {
        public NewProductDto Product { get; set; }
    }
}
