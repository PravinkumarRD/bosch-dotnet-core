﻿using Bosch.eCommerce.Application.Dtos.ProductDtos;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Products.Commands.DeleteCommand
{
    public class DeleteProductCommand:IRequest<int>
    {
        public int ProductId { get; set; }
    }
}
