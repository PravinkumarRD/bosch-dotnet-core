﻿using AutoMapper;
using Bosch.eCommerce.Application.Contacts;
using Bosch.eCommerce.Domain.Entities;
using MediatR;

namespace Bosch.eCommerce.Application.Features.Products.Commands.DeleteCommand
{
    public class DeleteProductCommandHandler : IRequestHandler<DeleteProductCommand, int>
    {
        private readonly ICommonRepository<Product> _repository;

        public DeleteProductCommandHandler(ICommonRepository<Product> repository)
        {
            _repository = repository;
        }

        public async Task<int> Handle(DeleteProductCommand request, CancellationToken cancellationToken)
        {
            int result = await _repository.DeleteAsync(request.ProductId);
            return result;
        }
    }
}
