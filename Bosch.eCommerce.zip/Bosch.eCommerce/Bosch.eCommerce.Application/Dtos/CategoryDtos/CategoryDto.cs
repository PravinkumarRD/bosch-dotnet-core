﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bosch.eCommerce.Application.Dtos.CategoryDtos
{
    public class CategoryDto
    {
        public int CatgeoryId { get; set; }
        public string CatgeoryName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}
