﻿using Bosch.eCommerce.Application.Dtos.ProductDtos;
using Bosch.eCommerce.Application.Features.Products.Commands;
using Bosch.eCommerce.Application.Features.Products.Commands.DeleteCommand;
using Bosch.eCommerce.Application.Features.Products.Queries.GetAllProducts;
using Bosch.eCommerce.Application.Features.Products.Queries.GetProductDetails;
using Bosch.eCommerce.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Bosch.eCommerce.UI.Areas.ProductsManager.Controllers
{
    [Area("ProductsManager")]
    public class HomeController : Controller
    {
        private readonly IMediator _mediator;

        public HomeController(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.PageTitle = "Welcome To Bosch Products List!";
            ViewBag.PageSubTitle = "Everything You Need Under Single Roof!";
            var products = await _mediator.Send(new GetAllProductsQuery());
            return View(products);
        }
        public async Task<IActionResult> Details(int id)
        {
            ViewBag.PageTitle = "Details Of - ";
            var product = await _mediator.Send(new GetProductDetailsQuery() { ProductId = id });
            return View(product);
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(NewProductDto product)
        {
            product.Picture = "/Images/bata_b_w_1.jpeg";
            product.CategoryId = 1;
            if (ModelState.IsValid)
            {
                var result = await _mediator.Send(new ProductInsertCommand() { Product = product });
                if (result > 0)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return View("Register");
                }
            }
            return View("Register");
        }

        public IActionResult DeleteConfirmation()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int productId)
        {
            var result = await _mediator.Send(new DeleteProductCommand() { ProductId=productId });
            if (result > 0)
            {
                return RedirectToAction("DeleteConfirmation");
            }
            else
            {
                return View("Register");
            }
        }


    }
}
