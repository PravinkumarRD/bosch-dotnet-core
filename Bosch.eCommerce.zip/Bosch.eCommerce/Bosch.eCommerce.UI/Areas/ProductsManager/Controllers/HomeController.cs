﻿using Bosch.eCommerce.Application.Dtos.ProductDtos;
using Bosch.eCommerce.Application.Features.Products.Commands;
using Bosch.eCommerce.Application.Features.Products.Commands.DeleteCommand;
using Bosch.eCommerce.Application.Features.Products.Queries.GetAllProducts;
using Bosch.eCommerce.Application.Features.Products.Queries.GetProductDetails;
using Bosch.eCommerce.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Localization;
using Microsoft.Extensions.Caching.Memory;
using System.Diagnostics;

namespace Bosch.eCommerce.UI.Areas.ProductsManager.Controllers
{
    [Area("ProductsManager")]
    public class HomeController : Controller
    {
        private readonly IHtmlLocalizer<HomeController> _localization;
        private readonly IMediator _mediator;
        private readonly IMemoryCache _memoryCache;
        private readonly string key = "productsCacheKey";
        public HomeController(IMediator mediator, IHtmlLocalizer<HomeController> localization, IMemoryCache memoryCache)
        {
            _mediator = mediator;
            _localization = localization;
            _memoryCache = memoryCache;
        }
        public async Task<IActionResult> Index()
        {
            ViewBag.PageTitle = _localization["PageTitle"];
            ViewBag.PageSubTitle = _localization["PageSubTitle"];
            if (_memoryCache.TryGetValue(key, out List<ProductDto> products))
            {
                return View(products);
            }
            products = await _mediator.Send(new GetAllProductsQuery());
            var cacheEntryOptions = new MemoryCacheEntryOptions()
                                        .SetSlidingExpiration(TimeSpan.FromSeconds(30))
                                        .SetAbsoluteExpiration(TimeSpan.FromMinutes(20));
            _memoryCache.Set(key, products, cacheEntryOptions);
            return View(products);
        }
        public async Task<IActionResult> Details(int id)
        {
            ViewBag.PageTitle = "Details Of - ";
            var product = await _mediator.Send(new GetProductDetailsQuery() { ProductId = id });
            return View(product);
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(NewProductDto product)
        {
            product.Picture = "/Images/bata_b_w_1.jpeg";
            product.CategoryId = 1;
            if (ModelState.IsValid)
            {
                var result = await _mediator.Send(new ProductInsertCommand() { Product = product });
                if (result > 0)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return View("Register");
                }
            }
            return View("Register");
        }

        public IActionResult DeleteConfirmation()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int productId)
        {
            var result = await _mediator.Send(new DeleteProductCommand() { ProductId = productId });
            if (result > 0)
            {
                return RedirectToAction("DeleteConfirmation");
            }
            else
            {
                return View("Register");
            }
        }


    }
}
