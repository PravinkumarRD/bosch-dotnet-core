﻿using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Auth0.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Facebook;
using Microsoft.AspNetCore.Http;

namespace Bosch.eCommerce.UI.Areas.SecurityManager.Controllers
{
    [Area("SecurityManager")]
    public class HomeController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
        public async Task GoogleLogin()
        {
            await HttpContext.ChallengeAsync(GoogleDefaults.AuthenticationScheme, new AuthenticationProperties()
            {
                RedirectUri = Url.Action("GoogleResponse")
            });
        }
        public async Task<IActionResult> GoogleResponse()
        {
            var result = await HttpContext.AuthenticateAsync(GoogleDefaults.AuthenticationScheme);
            var claims = result.Principal.Identities.FirstOrDefault().Claims.Select(claim =>
            new
            {
                claim.Issuer,
                claim.OriginalIssuer,
                claim.Type,
                claim.Value
            });
            Console.WriteLine(User.FindFirst(c => c.Type == ClaimTypes.Email)?.Value);
            HttpContext.Session.SetString("Admin", User.FindFirst(c => c.Type == ClaimTypes.Email)?.Value);
            Console.WriteLine(HttpContext.Session.GetString("Admin"));
            return RedirectToAction("Index", "Home", new { area = "" });
        }
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            HttpContext.Session.SetString("Admin", "");
            return RedirectToAction("Index", "Home", new { area = "" });
        }
        public async Task FacebookLogin()
        {
            var authenticationProperties = new LoginAuthenticationPropertiesBuilder()
                .WithRedirectUri("/")
                .Build();
            await HttpContext.ChallengeAsync(FacebookDefaults.AuthenticationScheme, authenticationProperties);
        }
        public async Task<IActionResult> FacebookLogout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Index", "Home", new { area = "" });
        }
    }
}
