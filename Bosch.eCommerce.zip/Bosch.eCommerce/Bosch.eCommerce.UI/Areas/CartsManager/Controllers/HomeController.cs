﻿using Bosch.eCommerce.Application.Dtos.ProductDtos;
using Bosch.eCommerce.Application.Features.Products.Queries.GetProductDetails;
using Bosch.eCommerce.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Bosch.eCommerce.UI.Areas.CartsManager.Controllers
{
    [Area("CartsManager")]
    public class HomeController : Controller
    {
        private readonly IMediator _mediator;

        public HomeController(IMediator mediator)
        {
            _mediator = mediator;
        }
        [Authorize]
        public async Task<IActionResult> Index(int id)
        {
            ViewBag.PageTitle = "Your Cart Items List!";
            if (HttpContext.Session.GetInt32("CustomerId") == null)
            {
                HttpContext.Session.SetInt32("CustomerId", 1);
            }
            if (HttpContext.Session.Get<Cart>("Cart") == null)
            {
                Cart cart = new Cart() { CustomerId = Convert.ToInt32(HttpContext.Session.GetInt32("CustomerId")), CartDate = DateTime.Now };
                HttpContext.Session.Set<Cart>("Cart", cart);
            }
            List<CartDetail> cartList;
            CartDetail cartItem = new CartDetail() { ProductId = id, Size = 7, Quantity = 1 };
            if (HttpContext.Session.Get<List<CartDetail>>("CartDetails") == null)
            {
                cartList = new List<CartDetail>();
                cartList.Add(cartItem);
                HttpContext.Session.Set<List<CartDetail>>("CartDetails", cartList);
            }
            else
            {
                cartList = HttpContext.Session.Get<List<CartDetail>>("CartDetails");
                cartList.Add(cartItem);
                HttpContext.Session.Set<List<CartDetail>>("CartDetails", cartList);
            }
            var product = await _mediator.Send(new GetProductDetailsQuery() { ProductId = id });

            if (HttpContext.Session.Get<List<ProductDto>>("CartProducts") == null)
            {
                List<ProductDto> productList = new List<ProductDto>();
                productList.Add(product);
                HttpContext.Session.Set<List<ProductDto>>("CartProducts", productList);
                
            }
            else
            {
                List<ProductDto> productsList = HttpContext.Session.Get<List<ProductDto>>("CartProducts");
                productsList.Add(product);
                HttpContext.Session.Set<List<ProductDto>>("CartProducts", productsList);
            }
            List<ProductDto> productDtos = HttpContext.Session.Get<List<ProductDto>>("CartProducts");
            return View(productDtos);
        }
    }
}
