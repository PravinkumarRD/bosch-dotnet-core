using Bosch.eCommerce.Application;
using Bosch.eCommerce.Infrastructure;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc.Razor;

var builder = WebApplication.CreateBuilder(args);
// Add services to the container.
//Configure Session - 
builder.Services.AddSession(options =>
{
    options.IdleTimeout = new TimeSpan(0, 20, 0);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = GoogleDefaults.AuthenticationScheme;
}).AddFacebook(options =>
{

    IConfigurationSection FBAuthNSection =
    builder.Configuration.GetSection("Authentication:Facebook");
    options.AppId = FBAuthNSection["ClientId"];
    options.AppSecret = FBAuthNSection["ClientSecret"];
})
               .AddGoogle(options =>
               {
                   IConfigurationSection googleAuthNSection =
                   builder.Configuration.GetSection("Authentication:Google");
                   options.ClientId = googleAuthNSection["ClientId"];
                   options.ClientSecret = googleAuthNSection["ClientSecret"];
                   options.ClaimActions.MapJsonKey("urn:google:picture", "picture");
                   options.ClaimActions.MapJsonKey("urn:google:email", "email");
               }).AddCookie(options =>
               {
                   options.Cookie.HttpOnly = true;
               });
//Localization Support in ASP.NET Core MVC Application
builder.Services.AddLocalization(options => options.ResourcesPath = "Resources");
builder.Services.AddControllersWithViews()
    .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
    .AddDataAnnotationsLocalization();
builder.Services.Configure<RequestLocalizationOptions>(options =>
{
    var supportedCultures = new[] { "es-ES", "en-IN", "fr-Fr", "de-DE" };
    options.SetDefaultCulture(supportedCultures[0])
        .AddSupportedCultures(supportedCultures)
        .AddSupportedUICultures(supportedCultures);
});

builder.Services.AddApplicationServices();
builder.Services.AddInfrastructureService(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

var supportedCultures = new[] { "es-ES", "en-IN", "fr-Fr", "de-DE" };

var localizationOptions = new RequestLocalizationOptions()
    .SetDefaultCulture(supportedCultures[1])
    .AddSupportedCultures(supportedCultures)
    .AddSupportedUICultures(supportedCultures);

app.UseRequestLocalization(localizationOptions);

app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.UseSession();


app.UseEndpoints(endpoints =>
{
    endpoints.MapAreaControllerRoute(
        name: "Security",
        areaName: "SecurityManager",
        pattern: "SecurityManager/{controller=Home}/{action=Login}/{id?}"
    );
    endpoints.MapAreaControllerRoute(
        name: "Categories",
        areaName: "CategoriesManager",
        pattern: "CategoriesManager/{controller=Home}/{action=Index}/{id?}"
    );
    endpoints.MapAreaControllerRoute(
        name: "Products",
        areaName: "ProductsManager",
        pattern: "ProductsManager/{controller=Home}/{action=Index}/{id?}"
    );
    endpoints.MapAreaControllerRoute(
        name: "Carts",
        areaName: "CartsManager",
        pattern: "CartsManager/{controller=Home}/{action=Index}/{id?}"
    );
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}"
    );
});

app.Run();
