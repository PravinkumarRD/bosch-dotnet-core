﻿using Microsoft.EntityFrameworkCore;
using Bosch.eCommerce.Domain.Entities;

namespace Bosch.eCommerce.Infrastructure
{
    public class BoschECommerceDbContext:DbContext
    {
        public BoschECommerceDbContext()
        {

        }
        public BoschECommerceDbContext(DbContextOptions options):base(options) { 
        }
        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Cart> Carts { get; set; }
        public virtual DbSet<CartDetail> CartDetails { get; set; }
        public virtual DbSet<Invoice> Invoices { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=BoschECommerceDb;Trusted_Connection=true;TrustServerCertificate=True");
            }
        }
    }
}