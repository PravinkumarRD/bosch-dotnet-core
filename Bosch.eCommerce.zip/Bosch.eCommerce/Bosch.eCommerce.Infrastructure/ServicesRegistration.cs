﻿using Bosch.eCommerce.Application.Contacts;
using Bosch.eCommerce.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Bosch.eCommerce.Infrastructure
{
    public static class ServicesRegistration
    {
        public static IServiceCollection AddInfrastructureService(this IServiceCollection services,IConfiguration configuration)
        {
            services.AddDbContext<BoschECommerceDbContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("BoscheCommerceConStr"));
            });
            services.AddScoped<ICommonRepository<Product>,CommonRepository<Product>>();
            services.AddScoped<ICommonRepository<Category>, CommonRepository<Category>>();
            return services;
        }
    }
}
