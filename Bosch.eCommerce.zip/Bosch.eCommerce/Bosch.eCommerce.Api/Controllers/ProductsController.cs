﻿using Bosch.eCommerce.Application.Dtos.ProductDtos;
using Bosch.eCommerce.Application.Features.Products.Queries.GetAllProducts;
using Bosch.eCommerce.Application.Features.Products.Queries.GetProductDetails;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Bosch.eCommerce.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ProductsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("GetAllProducts")]
        public async Task<IEnumerable<ProductDto>> Get()
        {
            return await _mediator.Send(new GetAllProductsQuery());
        }
        [HttpGet("GetProductDetails")]
        public async Task<ProductDto> Get(int id)
        {
            return await _mediator.Send(new GetProductDetailsQuery() { ProductId=id});
        }
    }
}
