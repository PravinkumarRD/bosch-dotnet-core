﻿namespace Bosch.eCommerce.Domain.Entities
{
    public class Employee
    {
    }
}
