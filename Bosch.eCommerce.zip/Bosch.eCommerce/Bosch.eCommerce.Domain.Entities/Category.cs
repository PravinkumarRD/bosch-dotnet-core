﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Bosch.eCommerce.Domain.Entities
{
    public class Category
    {
        [Key]
        public int CatgeoryId { get; set; }
        [Required(ErrorMessage ="Catgeory Name is a required field!")]
        [DisplayName("Category Name")]
        [MaxLength(100,ErrorMessage ="Category Name can no exceed more than 100 characters")]
        public string CatgeoryName { get; set; } = string.Empty;
        [Required(ErrorMessage = "Catgeory Description is a required field!")]
        [DisplayName("Category Description")]
        [MaxLength(300, ErrorMessage = "Category Description can no exceed more than 300 characters")]
        public string Description { get; set; } = string.Empty;
    }
}
